
import { useState } from "react";

export default function App() {
  const [bedtime, setBedtime] = useState(22);
  const [wakeTime, setWakeTime] = useState(6);
  const [reminder, setReminder] = useState(false);
  const [journal, setJournal] = useState("");
  const [saved, setSaved] = useState(false);

  const calculateSleepDuration = () => {
    let duration = wakeTime - bedtime;
    if (duration < 0) duration += 24;
    return duration;
  };

  const handleSave = () => {
    localStorage.setItem("bedtime", bedtime);
    localStorage.setItem("wakeTime", wakeTime);
    localStorage.setItem("reminder", reminder);
    localStorage.setItem("journal", journal);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-4xl font-bold mb-4 text-center">Routine de Sommeil</h1>

      <div className="bg-gray-800 p-4 rounded-lg mb-6">
        <h2 className="text-xl font-semibold">Heure du coucher</h2>
        <input
          type="number"
          min="0"
          max="23"
          value={bedtime}
          onChange={(e) => setBedtime(parseInt(e.target.value))}
          className="w-full p-2 rounded bg-gray-700 text-white mt-1 mb-4"
        />

        <h2 className="text-xl font-semibold">Heure du réveil</h2>
        <input
          type="number"
          min="0"
          max="23"
          value={wakeTime}
          onChange={(e) => setWakeTime(parseInt(e.target.value))}
          className="w-full p-2 rounded bg-gray-700 text-white mt-1 mb-4"
        />

        <p className="text-lg">
          Durée de sommeil estimée : {calculateSleepDuration()} heures
        </p>

        <label className="flex items-center mt-4">
          <input
            type="checkbox"
            checked={reminder}
            onChange={() => setReminder(!reminder)}
            className="mr-2"
          />
          Activer les rappels de coucher
        </label>
      </div>

      <div className="bg-gray-800 p-4 rounded-lg mb-6">
        <h2 className="text-xl font-semibold mb-2">Journal de Sommeil</h2>
        <textarea
          rows={4}
          placeholder="Notez comment vous vous sentez après votre nuit..."
          value={journal}
          onChange={(e) => setJournal(e.target.value)}
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>

      <div className="text-center space-y-2">
        <button
          className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded"
          onClick={handleSave}
        >
          Sauvegarder
        </button>
        {saved && <p className="text-green-400">Routine sauvegardée avec succès !</p>}
      </div>
    </div>
  );
}
